var obj;
var resultObject;
var pg;
var totalWorkitems;
var workitemsPerPage = 25;
selectedWorkItems = new Map();

jQuery("body").on('DOMSubtreeModified', '.sp-body', function() {
	if(jQuery('.text-ellipsis.ng-binding:first-child').length>0)
	{
		if(jQuery('#button1').length==0)
		{
			 jQuery("span[title='Latest Approvals']").after('<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 300px; top: 6px; margin: 0px;"> 	 	<em id="button2"> 	 		<button id="Overly" type="button"  class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;"> 	 			<span id="button4" class="x-btn-inner" style="">Bulk Action</span> 	 			<span id="button5" class="x-btn-icon "></span> 	 		</button> 	 	</em> 	 </div>');
		
				
				 jQuery('body').append(
			'<div id="ogrooModel" class="modalbox ogroobox">'+
				'<div class="dialog">'+
					 '<div style="min-height: 200px;">'+
					 	'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left">'+
						 	'<h4>Bulk Approve/Reject Request</h4>'+
						 '</div>'+
						 '<div style="visibility:hidden" id="error-text"></div>'+
						 '<div id="loader"></div>'+
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						
						'<div style="padding: 8px;">'+
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>'+
							'<span class="btn-group-xs-only">'+
							'<button style="visibility:hidden;float: right;" id="reject" onclick="reject()" aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
									'</button></span>'+ 
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
								'</label>'+
						'</div>'+
						'<br/>'+
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+'<button class="btn btn-default" onclick="dismissCommonComment()">Cancel</button>'+
								'<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
									
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
				'</div><span id="pgSpan" style="visibility:hidden"></span>');

				jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
                                                '</div>');
				if(jQuery('#button1').length!=0)
				{
				document.getElementById("Overly").addEventListener("click", function(){
			         	var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
			jQuery('#loader').after('<table id="item_table" style="visibility:hidden">'+
						 	'<thead>'+
							 	'<tr>'+
								 	'<th style="text-align: left ;width:2%;">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id)"/><b>&nbsp; '+
									'</th>'+
									
									'<th style="text-align: left; width:6%">ID</th>'+
									'<th style="text-align: left; width:5%">Requestee</th>'+
									'<th style="text-align: left; width:14%">Requester</th>'+
									'<th style="text-align: left; width:14%">Requested For</th>'+
									'<th style="text-align: left; width:4%">Application</th>'+
									'<th style="text-align: left; width:2%">Requested On</th>'+
									'<th style="text-align: left; width:12%">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			
			getData(workitemsPerPage,1);
			
			var tableData = document.getElementById('table1');
		});
		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			var cmntBox = document.getElementsByClassName('cmnt');
			var cAllbox = document.getElementById('All');
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");

			selectedWorkItems.clear();
		});
	
		}
	}
}
});