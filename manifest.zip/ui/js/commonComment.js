/*function dismiss()
{
                var el = document.getElementsByClassName("cmnt-modal");
                el[0].style.display = 'none';
                
                jQuery('#com-cmnt-checkbox')[0].checked = false;
                var comment = document.getElementById('comment');
                comment.value = "";
                var keys = selectedWorkItems.keys();

                selectedWorkItems.forEach(function(){
                                jQuery('#cmnt'+keys.next().value).removeAttr('disabled');                            
                })             
                selectedWorkItems.clear();
                var cboxes = document.getElementsByClassName('check');
                uncheckAll(cboxes);
                jQuery('#All')[0].checked = false;
}*/
function dismissCommonComment()
{
                var el = document.getElementsByClassName("cmnt-modal");
                el[0].style.display = 'none';
                
                jQuery('#com-cmnt-checkbox')[0].checked = false;
                var comment = document.getElementById('comment');
                comment.value = "";
                var keys = selectedWorkItems.keys();
                console.log(keys);
                
                selectedWorkItems.forEach(function(){
                                jQuery('#cmnt'+keys.next().value).removeAttr('disabled');                            
                })             
                //selectedWorkItems.clear();
                var cboxes = document.getElementsByClassName('check');
                /*if (selectedWorkItems.size > 0)
                {
                                //var com_val = '#cmnt'+keys;
                                val = selectedWorkItems.values();
                                console.log(val);
                }*/
                if (jQuery('.cmnt')[0].checked == true) 
                {
                                if (selectedWorkItems.size > 0)
                                {
                                                jQuery(this).attr("readonly", "readonly");
                                                var vals = selectedWorkItems.values();
                                                //console.log(val);
                                                /*var res={};
                                                res[keys.next().value] = vals.next().value;
                                                console.log(res);*/
                                                document.getElementById(this.id).value = vals.next().value;
                                }
                };
                //uncheckAll(cboxes);
                jQuery('#All')[0].checked = false;
}

function addCommonComment(objId)
{
                var comment = document.getElementById(objId);
                var keys = selectedWorkItems.keys();
                
                //if(selectedWorkItems.length > 0)
                //{
                                //console.log("abc");
                                selectedWorkItems.forEach(function(){
                                                selectedWorkItems.set(keys.next().value, comment.value);
                                })
                //}
}


function openCommonCommentBox()
{
                var el = document.getElementsByClassName("cmnt-modal");
                el[0].style.display = 'block';
                
                var chckBox = document.getElementById('com-cmnt-checkbox');

                if(chckBox.checked)
                {
                                //console.log(selectedWorkItems);
                                if(selectedWorkItems.size <= 0)
                                {
                                                jQuery('#error-text').css('visibility', 'visible');
                                                jQuery('#error-text').addClass("formWarn"); 
                                                jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
                                                jQuery('#cmnt-box').hide();
                                                chckBox.checked = false;
                                }
                                else
                                {
                                                jQuery('#cmnt-box').css("visibility", "visible");
                                                jQuery('#error-text').css('visibility', 'hidden');
                                                jQuery('#error-text').removeClass("formWarn"); 
                                                jQuery('#error-text')[0].innerHTML = "";
                                                jQuery('.cmnt').each(function() {
                                                                jQuery(this).attr("readonly", "readonly");
                                                                //var res = String(val);
                                                                //console.log(res);
                                                                //document.getElementById(this.id).value = res;
                                                })
                                }
                }

                else
                {
                                jQuery('#cmnt-box').css("visibility", "hidden");
                                
                                jQuery('.cmnt').each(function() {
                                                jQuery(this).removeAttr('readonly');                       
                                })

                                var keys = selectedWorkItems.keys();
                                selectedWorkItems.forEach(function(){
                                                selectedWorkItems.set(keys.next().value, "");
                                })
                                var cmntBox = document.getElementById('comment');
                                cmntBox.value = "";
                                
                }
                
}
